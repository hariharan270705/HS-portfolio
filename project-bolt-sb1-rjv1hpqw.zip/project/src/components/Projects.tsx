import { useState, useRef } from 'react';
import { Github, ExternalLink } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionHeading } from './SectionHeading';

interface Project {
  title: string;
  description: string;
  techStack: string[];
  github: string;
  demo: string;
  category: 'Web' | 'AI' | 'Open Source';
}

const projects: Project[] = [
  {
    title: 'AI-Tripl-Linker',
    description: 'AI-powered travel planner for personalized itineraries and navigation.',
    techStack: ['React', 'Node.js', 'Express', 'Tailwind CSS', 'AI API'],
    github: 'https://github.com/hariharan270705/ai-tripl-linker',
    demo: '#',
    category: 'AI',
  },
  {
    title: 'Plant-Doctor',
    description: 'Smart plant disease detection system using image recognition with treatment suggestions.',
    techStack: ['React', 'Python', 'Flask', 'TensorFlow', 'OpenCV', 'Tailwind CSS'],
    github: 'https://github.com/hariharan270705/plant-doctor',
    demo: '#',
    category: 'AI',
  },
  {
    title: 'Hostel Complaint Management',
    description: 'Web app for students to submit and track hostel complaints with admin dashboards.',
    techStack: ['React', 'Node.js', 'Express', 'MongoDB', 'Tailwind CSS'],
    github: 'https://github.com/hariharan270705/hostel-complaint-management',
    demo: '#',
    category: 'Web',
  },
  {
    title: 'Agro Smart',
    description: 'AI-based agriculture monitoring system providing insights for crop management.',
    techStack: ['React', 'Node.js', 'Express', 'Python', 'AI Models', 'Tailwind CSS'],
    github: 'https://github.com/hariharan270705/agro-smart',
    demo: '#',
    category: 'AI',
  },
  {
    title: 'Dear Attender',
    description: 'Student attendance tracking and notification system for colleges.',
    techStack: ['React', 'Node.js', 'Express', 'MongoDB', 'Tailwind CSS'],
    github: 'https://github.com/hariharan270705/dear-attender',
    demo: '#',
    category: 'Web',
  },
];

const categories = ['All', 'Web', 'AI', 'Open Source'];

function ProjectCard({ project, index }: { project: Project; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useIntersectionObserver(ref);

  return (
    <div
      ref={ref}
      className={`bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div className="h-48 bg-gradient-to-br from-blue-600 to-blue-400 flex items-center justify-center">
        <div className="text-6xl font-bold text-white opacity-20">
          {project.title.split('-')[0].substring(0, 2).toUpperCase()}
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
          {project.title}
        </h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">
          {project.description}
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          {project.techStack.map((tech) => (
            <span
              key={tech}
              className="px-3 py-1 text-xs font-medium bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full"
            >
              {tech}
            </span>
          ))}
        </div>

        <div className="flex space-x-4">
          <a
            href={project.github}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
          >
            <Github size={20} className="mr-2" />
            Code
          </a>
          {project.demo !== '#' && (
            <a
              href={project.demo}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              <ExternalLink size={20} className="mr-2" />
              Demo
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

export function Projects() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredProjects =
    selectedCategory === 'All'
      ? projects
      : projects.filter((project) => project.category === selectedCategory);

  return (
    <section id="projects" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading subtitle="Explore my latest work and contributions">
          Featured Projects
        </SectionHeading>

        <div className="flex justify-center flex-wrap gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-2 rounded-lg font-medium transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-blue-600 text-white shadow-lg scale-105'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <ProjectCard key={project.title} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
