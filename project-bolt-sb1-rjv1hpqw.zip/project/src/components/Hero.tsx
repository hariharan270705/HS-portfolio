import { Github, Linkedin, Mail, Twitter, Instagram, ChevronDown } from 'lucide-react';
import { useTypingEffect } from '../hooks/useTypingEffect';
import { Button } from './Button';

const socialLinks = [
  { icon: Github, href: 'https://github.com/hariharan270705', label: 'GitHub' },
  { icon: Linkedin, href: 'https://www.linkedin.com/in/hariharan-s-vibecoder', label: 'LinkedIn' },
  { icon: Twitter, href: 'https://x.com/Harirash123', label: 'Twitter' },
  { icon: Instagram, href: 'https://www.instagram.com/hariharan_sb', label: 'Instagram' },
  { icon: Mail, href: 'mailto:harirashgokul.com', label: 'Email' },
];

export function Hero() {
  const typedText = useTypingEffect('Exploring AI Tools & Engineering | Promoting Engineering Innovation & Awareness', 50);

  const scrollToProjects = () => {
    document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative bg-gradient-to-br from-blue-50 via-white to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 pt-16">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-purple-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-20 left-1/2 w-72 h-72 bg-pink-400 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
        <div className="text-center">
          <div className="mb-8 relative inline-block">
            <div className="w-48 h-48 mx-auto rounded-full bg-gradient-to-br from-blue-600 to-blue-400 p-1 shadow-2xl transform transition-transform duration-300 hover:scale-105">
              <div className="w-full h-full rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-6xl font-bold text-blue-600 dark:text-blue-400">
                HS
              </div>
            </div>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 dark:text-white mb-4 animate-fade-in">
            Hariharan S
          </h1>

          <h2 className="text-2xl md:text-3xl font-semibold text-blue-600 dark:text-blue-400 mb-6 animate-fade-in animation-delay-200">
            Web Developer
          </h2>

          <div className="h-20 mb-8">
            <p className="text-lg md:text-xl text-gray-700 dark:text-gray-300 animate-fade-in animation-delay-400">
              {typedText}
              <span className="animate-blink">|</span>
            </p>
          </div>

          <div className="flex justify-center space-x-4 mb-12 animate-fade-in animation-delay-600">
            {socialLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-full bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-300"
                aria-label={link.label}
              >
                <link.icon size={24} />
              </a>
            ))}
          </div>

          <div className="animate-fade-in animation-delay-800">
            <Button onClick={scrollToProjects}>
              View My Work
            </Button>
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ChevronDown size={32} className="text-gray-400 dark:text-gray-600" />
        </div>
      </div>
    </section>
  );
}
