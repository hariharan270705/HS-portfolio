import { useRef } from 'react';
import { Award, Trophy, Zap, Palette, FileText, Code } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionHeading } from './SectionHeading';

interface Achievement {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  title: string;
  description: string;
}

const achievements: Achievement[] = [
  {
    icon: Zap,
    title: 'Prompt Engineer',
    description: 'Expert in crafting effective prompts for AI models and optimizing LLM interactions.',
  },
  {
    icon: Palette,
    title: 'Figma Designer',
    description: 'Creating beautiful and functional UI/UX designs for web and mobile applications.',
  },
  {
    icon: Code,
    title: 'Frontend Developer',
    description: 'Building responsive and interactive user interfaces with modern frameworks.',
  },
  {
    icon: Trophy,
    title: 'MEARN Developer',
    description: 'Full-stack development expertise in MongoDB, Express, Angular/React, and Node.js.',
  },
  {
    icon: FileText,
    title: 'Content Writer',
    description: 'Technical writing and documentation for software projects and tutorials.',
  },
  {
    icon: Award,
    title: 'Hackathon Participant',
    description: 'Active participation in multiple hackathons and technical competitions.',
  },
];

function AchievementCard({ achievement, index }: { achievement: Achievement; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useIntersectionObserver(ref);

  return (
    <div
      ref={ref}
      className={`bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 ${
        isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
      }`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div className="flex items-start">
        <div className="flex-shrink-0">
          <div className="p-3 bg-gradient-to-br from-blue-600 to-blue-400 rounded-lg">
            <achievement.icon className="w-8 h-8 text-white" />
          </div>
        </div>
        <div className="ml-4">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            {achievement.title}
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            {achievement.description}
          </p>
        </div>
      </div>
    </div>
  );
}

export function Achievements() {
  return (
    <section id="achievements" className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading subtitle="Certifications, skills, and accomplishments">
          Achievements & Certifications
        </SectionHeading>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((achievement, index) => (
            <AchievementCard key={achievement.title} achievement={achievement} index={index} />
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="inline-block bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Additional Highlights
            </h3>
            <div className="flex flex-wrap justify-center gap-4">
              <span className="px-4 py-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full font-medium">
                Workshop Organizer
              </span>
              <span className="px-4 py-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full font-medium">
                Technical Speaker
              </span>
              <span className="px-4 py-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full font-medium">
                Event Coordinator
              </span>
              <span className="px-4 py-2 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full font-medium">
                Open Source Contributor
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
