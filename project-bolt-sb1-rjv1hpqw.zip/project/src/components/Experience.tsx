import { useRef } from 'react';
import { GraduationCap, Briefcase, Users } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionHeading } from './SectionHeading';

interface TimelineItem {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  title: string;
  organization: string;
  period: string;
  description: string;
  type: 'education' | 'work' | 'volunteer';
}

const timeline: TimelineItem[] = [
  {
    icon: GraduationCap,
    title: 'B.Tech in Computer Science & Business Systems',
    organization: 'Thiagarajar College of Engineering',
    period: '2022 - Present',
    description: 'Pre-Final Year student focusing on AI, web development, and software engineering.',
    type: 'education',
  },
  {
    icon: Briefcase,
    title: 'Intern',
    organization: 'Nano Intellect Solutions',
    period: '2024',
    description: 'Worked on full-stack web development projects and AI integrations.',
    type: 'work',
  },
  {
    icon: Users,
    title: 'Youth Red Cross Volunteer',
    organization: 'Thiagarajar College of Engineering',
    period: '2022 - Present',
    description: 'Organized department and college events, promoting engineering awareness and community service.',
    type: 'volunteer',
  },
];

function TimelineCard({ item, index }: { item: TimelineItem; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useIntersectionObserver(ref);

  const isEven = index % 2 === 0;

  return (
    <div
      ref={ref}
      className={`flex items-center mb-12 ${isEven ? 'md:flex-row' : 'md:flex-row-reverse'} ${
        isVisible ? 'opacity-100 translate-x-0' : `opacity-0 ${isEven ? '-translate-x-10' : 'translate-x-10'}`
      } transition-all duration-700`}
      style={{ transitionDelay: `${index * 200}ms` }}
    >
      <div className={`flex-1 ${isEven ? 'md:text-right md:pr-12' : 'md:pl-12'}`}>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
          <div className="flex items-center mb-3" style={{ justifyContent: isEven ? 'flex-end' : 'flex-start' }}>
            <div className={`p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg ${isEven ? 'ml-3' : 'mr-3'}`}>
              <item.icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
              {item.period}
            </span>
          </div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            {item.title}
          </h3>
          <p className="text-lg text-gray-700 dark:text-gray-300 font-medium mb-2">
            {item.organization}
          </p>
          <p className="text-gray-600 dark:text-gray-400">
            {item.description}
          </p>
        </div>
      </div>

      <div className="relative flex items-center justify-center flex-shrink-0">
        <div className="w-4 h-4 bg-blue-600 dark:bg-blue-400 rounded-full border-4 border-white dark:border-gray-900 z-10"></div>
        <div className="absolute h-full w-0.5 bg-blue-200 dark:bg-blue-800" style={{ top: '50%' }}></div>
      </div>

      <div className="flex-1"></div>
    </div>
  );
}

export function Experience() {
  return (
    <section id="experience" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading subtitle="My journey through education and work">
          Experience & Education
        </SectionHeading>

        <div className="relative">
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-blue-200 dark:bg-blue-800"></div>

          <div className="space-y-0">
            {timeline.map((item, index) => (
              <TimelineCard key={index} item={item} index={index} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
