import { useRef, useEffect, useState } from 'react';
import { Download, GraduationCap, Code, Trophy } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionHeading } from './SectionHeading';
import { Button } from './Button';

interface StatProps {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  end: number;
  label: string;
  suffix?: string;
}

function AnimatedStat({ icon: Icon, end, label, suffix = '' }: StatProps) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useIntersectionObserver(ref);

  useEffect(() => {
    if (isVisible) {
      let start = 0;
      const duration = 2000;
      const increment = end / (duration / 16);

      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 16);

      return () => clearInterval(timer);
    }
  }, [isVisible, end]);

  return (
    <div ref={ref} className="text-center p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
      <Icon className="w-12 h-12 mx-auto mb-4 text-blue-600 dark:text-blue-400" />
      <div className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
        {count}{suffix}
      </div>
      <div className="text-gray-600 dark:text-gray-400">{label}</div>
    </div>
  );
}

export function About() {
  const ref = useRef<HTMLElement>(null);
  const isVisible = useIntersectionObserver(ref);

  return (
    <section id="about" ref={ref} className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading subtitle="Get to know more about my journey">
          About Me
        </SectionHeading>

        <div className={`grid md:grid-cols-2 gap-12 items-center transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}>
          <div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-blue-400 rounded-2xl transform rotate-3"></div>
              <div className="relative bg-gray-200 dark:bg-gray-700 rounded-2xl p-8 flex items-center justify-center h-96">
                <div className="text-8xl font-bold text-blue-600 dark:text-blue-400">HS</div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white">
              Pre-Final Year CSBS Student
            </h3>
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
              I am Hariharan S, a Pre-Final Year CSBS student at Thiagarajar College of Engineering.
              Passionate about AI, web development, and engineering innovation, I build projects that combine creativity, technology, and practical solutions.
            </p>
            <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
              I actively participate in hackathons, workshops, and college events to promote engineering awareness.
              My goal is to leverage technology to create meaningful impact and contribute to the engineering community.
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <Button variant="primary">
                <Download size={20} className="inline mr-2" />
                Download Resume
              </Button>
              <Button
                variant="outline"
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Get In Touch
              </Button>
            </div>
          </div>
        </div>

        <div className={`grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 transition-all duration-1000 delay-300 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}>
          <AnimatedStat icon={GraduationCap} end={3} label="Years of Study" suffix="+" />
          <AnimatedStat icon={Code} end={15} label="Projects Completed" suffix="+" />
          <AnimatedStat icon={Trophy} end={10} label="Hackathons & Events" suffix="+" />
        </div>
      </div>
    </section>
  );
}
