import { useRef, useEffect, useState } from 'react';
import { GitBranch, Star, GitFork, Activity } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { SectionHeading } from './SectionHeading';

interface GitHubStats {
  publicRepos: number;
  followers: number;
  totalStars: number;
  totalForks: number;
}

interface StatCardProps {
  icon: React.ComponentType<{ size?: number; className?: string }>;
  value: number;
  label: string;
  index: number;
}

function StatCard({ icon: Icon, value, label, index }: StatCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isVisible = useIntersectionObserver(ref);

  return (
    <div
      ref={ref}
      className={`bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-500 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
      style={{ transitionDelay: `${index * 100}ms` }}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            {value}
          </p>
          <p className="text-gray-600 dark:text-gray-400">{label}</p>
        </div>
        <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
          <Icon className="w-8 h-8 text-blue-600 dark:text-blue-400" />
        </div>
      </div>
    </div>
  );
}

export function GitHubStats() {
  const [stats, setStats] = useState<GitHubStats>({
    publicRepos: 0,
    followers: 0,
    totalStars: 0,
    totalForks: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchGitHubStats = async () => {
      try {
        const userResponse = await fetch('https://api.github.com/users/hariharan270705');
        const userData = await userResponse.json();

        const reposResponse = await fetch('https://api.github.com/users/hariharan270705/repos?per_page=100');
        const reposData = await reposResponse.json();

        const totalStars = reposData.reduce((acc: number, repo: any) => acc + repo.stargazers_count, 0);
        const totalForks = reposData.reduce((acc: number, repo: any) => acc + repo.forks_count, 0);

        setStats({
          publicRepos: userData.public_repos || 0,
          followers: userData.followers || 0,
          totalStars,
          totalForks,
        });
      } catch (error) {
        console.error('Error fetching GitHub stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchGitHubStats();
  }, []);

  return (
    <section id="github" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading subtitle="My contributions and activity on GitHub">
          GitHub Statistics
        </SectionHeading>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <StatCard icon={GitBranch} value={stats.publicRepos} label="Public Repos" index={0} />
              <StatCard icon={Activity} value={stats.followers} label="Followers" index={1} />
              <StatCard icon={Star} value={stats.totalStars} label="Total Stars" index={2} />
              <StatCard icon={GitFork} value={stats.totalForks} label="Total Forks" index={3} />
            </div>

            <div className="flex flex-col items-center space-y-6">
              <img
                src="https://github-readme-stats.vercel.app/api?username=hariharan270705&show_icons=true&theme=tokyonight&hide_border=true&bg_color=1a202c&title_color=3b82f6&icon_color=3b82f6&text_color=e5e7eb"
                alt="GitHub Stats"
                className="rounded-xl shadow-lg w-full max-w-2xl"
                loading="lazy"
              />

              <img
                src="https://github-readme-streak-stats.herokuapp.com/?user=hariharan270705&theme=tokyonight&hide_border=true&background=1a202c&ring=3b82f6&fire=3b82f6&currStreakLabel=3b82f6"
                alt="GitHub Streak"
                className="rounded-xl shadow-lg w-full max-w-2xl"
                loading="lazy"
              />

              <img
                src="https://github-readme-stats.vercel.app/api/top-langs/?username=hariharan270705&layout=compact&theme=tokyonight&hide_border=true&bg_color=1a202c&title_color=3b82f6&text_color=e5e7eb"
                alt="Top Languages"
                className="rounded-xl shadow-lg w-full max-w-2xl"
                loading="lazy"
              />
            </div>
          </>
        )}
      </div>
    </section>
  );
}
